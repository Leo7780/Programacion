//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
import javax.swing.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("Ingresa el nombre de la universidad :" );
        String nombreUniversidad =  scanner.nextLine();

        System.out.println("ingresa el nombre id:");
        String nombreI = scanner.nextLine();

        Universidad universidad = new Universidad(nombreUniversidad, nombreI);

        System.out.println("ingrese el nombre del estudiante");
        String nombreEstudiantes = scanner.nextLine();

        System.out.println("ingrese la carrera del estudiante");
        String nombrecarrera = scanner.nextLine();

        System.out.println("ingrese el correo del estudiante");
        String nombrecorreo = scanner.nextLine();

        Estudiante estudiante = new Estudiante(nombreEstudiantes,nombrecarrera,nombrecorreo);

        System.out.println("ingrese su materia 1: ");
        String nombremat1 = scanner.nextLine();

        System.out.println("ingrese su materia 2");
        String nombremat2 = scanner.nextLine();

        System.out.println("ingrese su materia 3 ");
        String nombremat3 = scanner.nextLine();

        Materia materia = new Materia(nombremat1, nombremat2, nombremat3);


        System.out.println("ingrese su curso 1 ");
        String nombrecurso1 = scanner.nextLine();

        System.out.println("ingrese su curso 2");
        String nombrecurso2 = scanner.nextLine();

        System.out.println("ingrese su curso 3");
        String nombrecurso3 = scanner.nextLine();

        Cursos cursos = new Cursos(nombrecurso1, nombrecurso2, nombrecurso3);

        System.out.println(universidad.detalleUniversidad());
        System.out.println(estudiante.detalleEstudiante());
        System.out.println(materia.detallematerias());
        System.out.println(cursos.detallecursos());




    }
}