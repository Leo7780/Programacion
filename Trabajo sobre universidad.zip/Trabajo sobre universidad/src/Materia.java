public class Materia {
    private String materia1;
    private String materia2;
    private String materia3;

    public Materia(String materia1, String materia2, String materia3) {
        this.materia1 = materia1;
        this.materia2 = materia2;
        this.materia3 = materia3;
    }
    public String getMateria1() {
        return materia1;
    }
    public void setMateria1(String materia1) {
        this.materia1 = materia1;
    }
    public String getMateria2() {
        return materia2;
    }
    public void setMateria2(String materia2) {
        this.materia2 = materia2;
    }
    public String getMateria3() {
        return materia3;
    }
    public void setMateria3(String materia3) {
        this.materia3 = materia3;
    }
    public String detallematerias(){
        String dm = "La materia 1 es: "+ this.materia1 + "\n"+"la materia 2 es: "+ this.materia2+
        "\n"+"La materia 3 es: " + this.materia3;
        return dm;
    }
}
