public class Universidad {

    private String nombre;
    private String IDE;


    public Universidad(String nombre, String IDE) {
        this.nombre = nombre;
        this.IDE = IDE;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getIDE() {
        return IDE;
    }

    public void setIDE(String IDE) {
        this.IDE = IDE;
    }

    public String detalleUniversidad (){
        String du = "el nombre es:"+ this.nombre + ("\n")+ "El ID es:" + this.IDE;
        return  du;
    }
}
