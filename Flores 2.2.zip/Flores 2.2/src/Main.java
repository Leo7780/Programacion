
public class Main {
    public static void main(String[] args) {
        Flores margarita = new Flores();
        margarita.ingresarcolor("verde");
        margarita.ingresartamano("Grande");
        margarita.ingresartipo("orquidea");
        margarita.ingresarcosto(23);
        System.out.println("El color de la margarita es = " +margarita.leercolor());
        System.out.println("el tamaño de la margarita es  = " + margarita.leertamano());
        System.out.println(" el tipo es una margarita es = " +margarita.leertipo());
        System.out.println(" el costo es = " +margarita.leercosto() );

        //System.out.println(" = " +margarita.detalleflores() );


    }
}