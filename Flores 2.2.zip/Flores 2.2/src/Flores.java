public class Flores{
    private String color;
    private String tamano;
    private String tipo;
    private double costo;



   public String detalleflores(){
        String df = "el color es -> " + this.color +" \n"+ " el tamaño es -> " + this.tamano +" \n"+
                " el tipo es  -> " + this.tipo +" \n"+ " el costo es -> "+ this.costo;
        return df;
    }

    public String leercolor(){
        this.color = color;
        return this.color;
     }
     public String leertamano(){
        this.tamano = tamano;
        return this.tamano;
     }
     public String leertipo(){
         this.tipo = tipo;
         return this.tipo;
     }
     public double leercosto(){
         this.costo = costo;
         return this.costo;
     }

    public String ingresarcolor(String color){
        this.color = color;
        return this.color;
     }
     public String ingresartamano(String tamano){
        this.tamano = tamano;
        return this.tamano;
     }
     public String ingresartipo(String tipo){
        this.tipo = tipo;
        return this.tipo;
     }
     public double ingresarcosto( double costo){
        this.costo = costo;
        return  this.costo;
     }
}
