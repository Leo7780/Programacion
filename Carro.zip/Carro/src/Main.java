import java.util.Scanner;


public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);


        System.out.println(" Ingrese el marca del auto " );
        String marca = scanner.nextLine();


        System.out.println(" Ingrese el modelo del auto " );
        String modelo = scanner.nextLine();

        System.out.println(" Ingrese el color del auto  ");
        String color = scanner.nextLine();

        System.out.println(" Ingrese el cilindraje " );
        double cilindraje = scanner.nextDouble();
        scanner.nextLine();

        Automovil automovil = new Automovil(marca,modelo,color,cilindraje);

        System.out.println(" \n"+ automovil.detalleauto() );

    }
}